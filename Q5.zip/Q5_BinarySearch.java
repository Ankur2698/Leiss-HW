// Java program for implementing iterative Binary Search

import java.time.*;
import java.io.FileWriter;
import java.io.IOException;

public class Q5_BinarySearch {

    // This is an iterative binary search function that returns the location
    // for a provided target value in a given array, arr[left..right], if present.
    // Otherwise, it will return -1.
    // left is the starting location for the search and right is the last location
    int binarySearch(int arr[], int left, int right, int target)
    {
        while (left <= right) {
            int middle = left + (right - left) / 2;

            // Check if target is present at middle location
            if (arr[middle] == target)
                return middle;

            // If target is greater than the middle, ignore the left half of the array
            if (arr[middle] < target)
                left = middle + 1;

            // If target is smaller than the middle, ignore the right half of the array
            else
                right = middle - 1;
        }

        // This statement will be reached only when the target is not present
        return -1;
    }

    // This is the main function which will call the binarySearch function.
    // For each of the hard-coded sizes of arrays for the search: the function will first
    // create a test case array of increasing consecutive integers from 1 to the array size for the
    // current iteration. Then, it will measure the time it takes to do 10,000,000 unsuccessful
    // binary searches for the current array size and write it to an output file.
    public static void main(String args[])
    {
        try
        {
            FileWriter timings = new FileWriter("Q5 Java Timings.txt");
            timings.write("--- Binary Search Timings for Java ---\n");
            Clock timer = Clock.systemDefaultZone();
            Q5_BinarySearch searcher = new Q5_BinarySearch();

            int sizes[] = {128, 512, 2048, 8192, 32768, 131072, 524288, 2097152};
            int numOfSearches = 10000000;

            for (int i = 0; i < 8; i++)
            {
                int arr[] = new int[sizes[i]];
                for (int j = 0; j < sizes[i]; j++)
                    arr[j] = j + 1;

                long milliseconds = timer.millis();
                for (int k = 0; k < numOfSearches; k++)
                    searcher.binarySearch(arr, 0, sizes[i] - 1, sizes[i] + 1);
                milliseconds = timer.millis() - milliseconds;
                double searchTime = (double) milliseconds / 1000;
                timings.write("Time taken to do " + numOfSearches + " binary searches for an array of size "
                        + sizes[i] + " is " + searchTime + " seconds.\n");
            }
            timings.close();
            System.out.println("End of program.");
        }
        catch (IOException e)
        {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
