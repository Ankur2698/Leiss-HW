# Python program for implementing iterative Binary Search

import time

# This is an iterative binary search function that returns the location
# for a provided target value in a given array, arr[left..right], if present.
# Otherwise, it will return -1.
# left is the starting location for the search and right is the last location
def binarySearch(arr, left, right, target):
    while left <= right:

        middle = left + (right - left) // 2

        # Check if target is present at middle location
        if arr[middle] == target:
            return middle

        # If target is greater than the middle, ignore the left half of the array
        elif arr[middle] < target:
            left = middle + 1

        # If target is smaller than the middle, ignore the right half of the array
        else:
            right = middle - 1

    # This statement will be reached only when the target is not present
    return -1


# The program will start executing the code from here and will call the binarySearch function.
# For each of the hard-coded sizes of arrays for the search: the program will first
# create a test case array of increasing consecutive integers from 1 to the array size for the
# current iteration. Then, it will measure the time it takes to do 10,000,000 unsuccessful
# binary searches for the current array size and write it to an output file.

timings = open("Q5 Python Timings.txt", "w")
timings.write("--- Binary Search Timings for Python ---\n")

sizes = [128, 512, 2048, 8192, 32768, 131072, 524288, 2097152]
numOfSearches = 10000000

for i in range(8):
    # Driver Code
    arr = [0 for x in range(sizes[i])]
    for j in range(sizes[i]):
        arr[j] = j+1
    # Function call
    timer = time.time()
    for k in range(numOfSearches):
        result = binarySearch(arr, 0, (sizes[i] - 1), sizes[i] + 1)
    timer = time.time()-timer
    timings.write("Time taken to do %d binary searches for an array of size %d is %f seconds.\n" %
                  (numOfSearches, sizes[i], timer))

timings.close()
print("End of program.\n")
